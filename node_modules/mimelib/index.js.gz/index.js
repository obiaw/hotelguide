"use strict";

module.exports = require("./lib/mimelib");
module.exports.contentTypes = require("./lib/content-types");
module.exports.contentTypesReversed = require("./lib/content-types-reversed");