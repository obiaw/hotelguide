# AWS SDK for JavaScript APIs Package

This package contains all of the API definitions used by the
[aws-sdk](https://github.com/aws/aws-sdk-js) package.
