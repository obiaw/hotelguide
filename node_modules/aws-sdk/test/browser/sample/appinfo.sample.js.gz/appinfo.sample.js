// Fill these in with your application details
appInfo = {
  amazon: {
    appId: '...',
    roleArn: '...'
  },
  facebook: {
    appId: '...',
    roleArn: '...'
  },
  google: {
    appId: '...',
    roleArn: '...'
  }
};
