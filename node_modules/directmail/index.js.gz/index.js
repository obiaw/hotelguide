'use strict';

// expose to the world
module.exports = require('./lib/mailer');