# Changelog

## v0.3.2 2015-01-07

  * Added changelog
  * Allow semicolon (;) as address separator in addition to comma (,). Backport from https://github.com/whiteout-io/addressparser/pull/5
